#!/bin/bash

# Активируем виртуальное окружение
source venv/bin/activate

# Обновляем pip

# Устанавливаем зависимости

# Запускаем бота
python main.py 
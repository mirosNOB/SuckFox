import os
import json
import asyncio
import logging
import shutil
import tempfile
import random
import aiohttp
from typing import Dict, Optional, Iterator, AsyncGenerator, List, Tuple
from datetime import datetime
from pathlib import Path
import time
from datetime import timedelta

import g4f
from g4f.errors import VersionNotFoundError
import g4f.Provider as Provider
from g4f.Provider import ProviderUtils
from g4f.providers.base_provider import ProviderModelMixin
from g4f.providers.retry_provider import BaseRetryProvider
from g4f.providers.helper import format_image_prompt
from g4f.providers.response import *
from g4f.tools.run_tools import iter_run_tools
from g4f import version, models, debug
from g4f import ChatCompletion, get_model_and_provider
import g4f.cookies
from g4f.cookies import get_cookies
from aiogram import Bot

# Настраиваем логирование
logger = logging.getLogger(__name__)

# Создаем директорию для cookies если её нет
cookies_dir = Path.home() / ".local/share/g4f"
cookies_dir.mkdir(parents=True, exist_ok=True)

debug.logging = True
g4f.debug.logging = True  # Включаем отладку g4f

# Настраиваем провайдеров
g4f.check_version = False  # Отключаем проверку версии
g4f.logging = True  # Включаем логирование

# Настройка сессии и cookies
g4f.debug.last_provider = None
g4f.debug.version_check = False
g4f.debug.stream = False  # Отключаем стриминг

# Настраиваем рабочие провайдеры
WORKING_PROVIDERS = [
    "You",
    "DeepAi",
    "Bing",
    "OpenAssistant",
    "Liaobots",
    "Phind",
    "Vercel",
    "Aichat",
    "ChatBase",
    "GptGo",
    "AiService",
    "GptForLove",
    "OnlineGpt",
    "Ylokh",
    "Yqcloud",
    "AItianhu",
    "EasyChat",
    "Hashnode",
    "Theb",
    "Acytoo",
    "Myshell",
    "AiAsk",
    "ChatgptAi",
    "FakeGpt",
    "FreeGpt",
    "GPTalk",
    "GptForFree",
    "Opchatgpts",
    "Wewordle",
]

# Глобальное хранилище разговоров
conversations: dict[dict[str, BaseConversation]] = {}

# Хранилище выбранных моделей
user_models: Dict[int, str] = {}

def get_error_message(e: Exception) -> str:
    """Получение текста ошибки"""
    return f"{type(e).__name__}: {e}"

def get_working_provider(model_name: str = None) -> Optional[ProviderModelMixin]:
    """Получение рабочего провайдера"""
    available_providers = []
    
    # Перебираем все провайдеры
    for provider_name in WORKING_PROVIDERS:
        try:
            provider = getattr(Provider, provider_name)
            if hasattr(provider, "working") and provider.working:
                # Если модель не указана или поддерживается провайдером
                if not model_name or (
                    hasattr(provider, "supports_model") and 
                    provider.supports_model(model_name)
                ):
                    available_providers.append(provider)
        except AttributeError:
            continue
    
    # Возвращаем случайный рабочий провайдер
    if available_providers:
        provider = random.choice(available_providers)
        logger.info(f"Выбран провайдер: {provider.__name__}")
        return provider
    return None

# Отключаем неработающие провайдеры
for provider_name in WORKING_PROVIDERS:
    try:
        provider = getattr(Provider, provider_name)
        if hasattr(provider, "working"):
            provider.working = True
            logger.info(f"Включен провайдер: {provider_name}")
    except AttributeError:
        continue

def get_available_models():
    """Получение списка моделей"""
    return [{
        "name": model.name,
        "image": isinstance(model, models.ImageModel),
        "vision": isinstance(model, models.VisionModel),
        "providers": [
            getattr(provider, "parent", provider.__name__)
            for provider in providers
            if provider.working
        ]
    }
    for model, providers in models.__models__.values()]

def prepare_conversation_kwargs(message_text: str, conversation_id: str = None, user_id: int = None) -> dict:
    """Подготовка параметров для разговора"""
    kwargs = {}
    
    # Базовые параметры
    kwargs["tool_calls"] = [{
        "function": {
            "name": "bucket_tool"
        },
        "type": "function"
    }]
    
    # Добавляем сообщение
    messages = []
    messages.append({
        "role": "user",
        "content": message_text
    })
    
    # Получаем модель пользователя если есть
    model = None
    if user_id:
        if str(user_id) in user_models:
            model = user_models[str(user_id)]
        else:
            # Если модель не выбрана, используем дефолтную
            model = DEFAULT_PROVIDERS[0]['models'][0]
            user_models[str(user_id)] = model
    
    # Возвращаем подготовленные параметры
    return {
        "model": model,  # Теперь всегда будет модель
        "provider": None,  # Провайдер всегда автоматически
        "messages": messages,
        "stream": False,  # Отключаем стриминг
        "ignore_stream": True,
        "return_conversation": True,
        "user_id": str(user_id) if user_id else None,  # Добавляем user_id для отслеживания
        **kwargs
    }

async def create_response_stream(kwargs: Dict, user_id: str) -> AsyncGenerator[str, None]:
    """Создает поток ответов от провайдера"""
    providers_tried = set()
    last_error = None
    html_providers = set()  # Провайдеры, вернувшие HTML
    rate_limited_providers = set()  # Провайдеры с превышением лимита
    
    # Первая попытка - без прокси
    async for response in _try_providers(kwargs, providers_tried, html_providers, rate_limited_providers):
        yield response
        return

    # Если все провайдеры не сработали, пробуем с прокси
    logger.info("Все провайдеры недоступны, пробуем с прокси...")
    proxy = await get_working_proxy()
    
    if proxy:
        logger.info(f"Используем прокси: {proxy}")
        # Очищаем списки использованных провайдеров для повторной попытки
        providers_tried.clear()
        html_providers.clear()
        rate_limited_providers.clear()
        
        # Добавляем прокси в параметры
        kwargs['proxy'] = proxy
        
        # Пробуем снова с прокси
        async for response in _try_providers(kwargs, providers_tried, html_providers, rate_limited_providers):
            yield response
            return
    
    # Если все попытки не удались
    error_msg = (
        "❌ Не удалось получить ответ от провайдеров.\n"
        f"Перепробовано провайдеров: {len(providers_tried)}\n"
        f"Вернули HTML: {len(html_providers)}\n"
        f"Превышен лимит: {len(rate_limited_providers)}\n"
        f"Последняя ошибка: {last_error}"
    )
    logger.error(error_msg)
    yield error_msg

async def _try_providers(
    kwargs: Dict,
    providers_tried: set,
    html_providers: set,
    rate_limited_providers: set
) -> AsyncGenerator[str, None]:
    """Пробует получить ответ от доступных провайдеров"""
    user_id = kwargs.get('user_id', 'unknown')
    current_model = kwargs.get('model')
    
    if not current_model:
        # Если модель не указана, берем первую доступную
        current_model = DEFAULT_PROVIDERS[0]['models'][0]
        logger.info(f"Модель не указана, используем {current_model}")
    
    # Получаем список провайдеров для текущей модели
    available_providers = [
        p for p in DEFAULT_PROVIDERS 
        if current_model in p['models'] and 
        p['provider'] not in providers_tried and
        p['provider'] not in html_providers and
        p['provider'] not in rate_limited_providers
    ]
    
    if not available_providers:
        yield f"❌ Нет доступных провайдеров для модели {current_model}"
        return
    
    for provider_info in available_providers:
        provider = provider_info['provider']
        providers_tried.add(provider)
        
        try:
            logger.info(f"Пробуем провайдера {provider.__name__} с моделью {current_model}")
            
            # Проверяем поддержку стриминга
            if hasattr(provider, 'StreamCreateResult'):
                async for response in provider.create_async(**{**kwargs, "model": current_model}):
                    if is_html_response(response):
                        html_providers.add(provider)
                        break
                    yield response
                return
            else:
                response = await provider.create_async(**{**kwargs, "model": current_model})
                if is_html_response(response):
                    html_providers.add(provider)
                    continue
                yield response
                return
                
        except Exception as e:
            error_str = str(e).lower()
            if 'rate' in error_str and 'limit' in error_str:
                rate_limited_providers.add(provider)
                logger.warning(f"Провайдер {provider.__name__} превысил лимит запросов")
            else:
                logger.error(f"Ошибка при использовании провайдера {provider.__name__}: {str(e)}")
            continue

def is_html_response(response: str) -> bool:
    """Проверяет, является ли ответ HTML"""
    response_lower = response.lower().strip()
    html_indicators = ['<!doctype html>', '<html', '<head', '<body', '<script']
    return any(indicator in response_lower for indicator in html_indicators)

# Конфигурация провайдеров и моделей
DEFAULT_PROVIDERS = [
    {
        'provider': g4f.Provider.Liaobots,
        'models': ['gpt-4', 'gpt-4o', 'llama-3.3-70b', 'claude-3.5-sonnet', 'grok-2', 'gpt-4o-mini', 'deepseek-r1', 'deepseek-v3', 'claude-3-opus', 'gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-2.0-flash']
    },
    {
        'provider': g4f.Provider.GigaChat,
        'models': ['GigaChat:latest']
    },
    {
        'provider': g4f.Provider.DeepInfraChat,
        'models': ['llama-3.1-8b', 'llama-3.2-90b', 'llama-3.3-70b', 'deepseek-v3', 'mixtral-small-28b', 'deepseek-r1', 'phi-4']
    },
    {
        'provider': g4f.Provider.Jmuz,
        'models': ['claude-3-haiku', 'claude-3-opus', 'claude-3.5-sonnet', 'deepseek-r1', 'gemini-1.5-flash', 'gemini-1.5-pro', 'llama-3.3-70b']
    },
    {
        'provider': g4f.Provider.DDG,
        'models': ['o3-mini', 'gpt-4', 'gpt-4o-mini', 'claude-3-haiku', 'llama-3.3-70b', 'mixtral-8x7b']
    },
    {
        'provider': g4f.Provider.Blackbox,
        'models': ['gpt-4', 'gpt-4o', 'llama-3.3-70b', 'gemini-1.5-pro', 'gemini-2.0-flash']
    },
    {
        'provider': g4f.Provider.You,
        'models': ['gpt-4', 'gpt-4o', 'llama-3.3-70b', 'claude-3-opus']
    },
    {
        'provider': g4f.Provider.bing,
        'models': ['gpt-4', 'gpt-4o', 'claude-3-opus']
    },
    {
        'provider': g4f.Provider.Phind,
        'models': ['gpt-4', 'gpt-4o', 'claude-3-opus']
    },
    {
        'provider': g4f.Provider.Anthropic,
        'models': ['claude-3-opus', 'claude-3.5-sonnet', 'claude-3-haiku']
    }
]

async def try_gpt_request(prompt: str, posts_text: str, user_id: int, bot: Bot, user_data: dict):
    """Пытаемся получить ответ от GPT с использованием прокси при необходимости"""
    text_length = len(posts_text)
    
    # Определяем оптимальную модель на основе размера данных
    if text_length > 50000:  # Для больших объемов данных
        preferred_models = [
            'claude-3-opus',  # ~150k токенов
            'gpt-4',         # ~50k токенов
            'claude-3.5-sonnet',  # ~50k токенов
            'llama-3.3-70b',  # ~30k токенов
            'deepseek-v3',   # ~30k токенов
            'mixtral-8x7b'   # ~30k токенов
        ]
    elif text_length > 25000:  # Для средних объемов данных
        preferred_models = [
            'claude-3.5-sonnet',
            'gpt-4',
            'llama-3.3-70b',
            'deepseek-v3'
        ]
    else:  # Для небольших объемов данных
        preferred_models = [user_data.get_user_data(user_id)['ai_settings']['model']]
    
    last_error = None
    rate_limited_providers = set()
    
    # Отправляем сообщение о начале анализа
    status_message = await bot.send_message(
        user_id,
        f"🔄 Начинаю анализ...\n"
        f"Размер данных: {text_length} символов"
    )
    
    # Пробуем сначала без прокси
    for model in preferred_models:
        try:
            await status_message.edit_text(
                f"🔄 Пробую модель {model} без прокси..."
            )
            
            response = await g4f.ChatCompletion.create_async(
                model=model,
                messages=[
                    {"role": "system", "content": "Ты мой личный ассистент для анализа данных. Ты всегда отвечаешь кратко и по делу, без лишних слов."},
                    {"role": "user", "content": f"{prompt}\n\nДанные для анализа:\n{posts_text}"}
                ],
                timeout=60
            )
            
            if response and len(response.strip()) > 0:
                await status_message.delete()
                return response
                
        except Exception as e:
            error_str = str(e)
            last_error = error_str
            logger.error(f"Ошибка с моделью {model} без прокси: {error_str}")
            
            if "429" in error_str or "ERR_INPUT_LIMIT" in error_str:
                rate_limited_providers.add(model)
                
    # Если без прокси не получилось, пробуем с прокси
    proxy = await proxy_manager.get_proxy()
    if proxy:
        for model in preferred_models:
            if model in rate_limited_providers:
                continue
                
            try:
                await status_message.edit_text(
                    f"🔄 Пробую модель {model} через прокси..."
                )
            
                response = await g4f.ChatCompletion.create_async(
                    model=model,
                    messages=[
                        {"role": "system", "content": "Ты мой личный ассистент для анализа данных. Ты всегда отвечаешь кратко и по делу, без лишних слов."},
                        {"role": "user", "content": f"{prompt}\n\nДанные для анализа:\n{posts_text}"}
                    ],
                    proxy=proxy,
                    timeout=60
                )
            
                if response and len(response.strip()) > 0:
                    await status_message.delete()
                    return response
                    
            except Exception as e:
                error_str = str(e)
                last_error = error_str
                logger.error(f"Ошибка с моделью {model} через прокси {proxy}: {error_str}")
                
                if "429" in error_str or "ERR_INPUT_LIMIT" in error_str:
                    rate_limited_providers.add(model)
                    await asyncio.sleep(5.0)
                else:
                    await asyncio.sleep(1.0)
                    
    # Если все попытки не удались
    error_msg = (
        "❌ Не удалось обработать данные. "
        f"Перепробовано моделей: {len(preferred_models)}\n"
        f"Модели с превышением лимита: {len(rate_limited_providers)}\n"
        f"Последняя ошибка: {last_error}"
    )
    await status_message.edit_text(error_msg)
    raise Exception(error_msg)

async def get_free_proxies() -> List[str]:
    """Получение списка бесплатных прокси"""
    proxies = []
    
    # Список API с бесплатными прокси
    proxy_apis = [
        "https://proxyfreeonly.com/api/free-proxy-list?limit=500&page=1&sortBy=lastChecked&sortType=desc",
        "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
        "https://www.proxy-list.download/api/v1/get?type=http"
    ]
    
    async with aiohttp.ClientSession() as session:
        for api in proxy_apis:
            try:
                async with session.get(api, timeout=10) as response:
                    if response.status == 200:
                        if 'proxyfreeonly.com' in api:
                            # Специальная обработка для proxyfreeonly.com
                            data = await response.json()
                            for proxy in data:
                                if proxy.get('protocols') and proxy.get('ip') and proxy.get('port'):
                                    for protocol in proxy['protocols']:
                                        proxy_str = f"{protocol.lower()}://{proxy['ip']}:{proxy['port']}"
                                        if proxy.get('anonymityLevel') == 'elite' and proxy.get('upTime', 0) > 80:
                                            proxies.append(proxy_str)
                        else:
                            # Обработка других API
                            text = await response.text()
                            proxy_list = [
                                f"http://{proxy.strip()}" 
                                for proxy in text.split('\n') 
                                if proxy.strip() and ':' in proxy
                            ]
                            proxies.extend(proxy_list)
                            
            except Exception as e:
                logger.warning(f"Ошибка при получении прокси из {api}: {str(e)}")
                continue
    
    return list(set(proxies))  # Убираем дубликаты

class ProxyManager:
    def __init__(self):
        self.proxies = []
        self.last_update = None
        self.cache_duration = 1800  # 30 минут
        self.working_proxies = {}  # Кэш рабочих прокси
        self.failed_proxies = set()  # Множество неработающих прокси
        self.trusted_proxies = [
            # Быстрые HTTP прокси с подтвержденной работоспособностью
            {"ip": "165.232.129.150", "port": "80", "protocol": "http", "upTime": 34.3, "speed": 6660, "response_time": 0.417},
            {"ip": "154.12.242.178", "port": "8080", "protocol": "http", "upTime": 80.0, "speed": 7533, "response_time": 0.418},
            {"ip": "87.248.129.26", "port": "80", "protocol": "http", "upTime": 69.1, "speed": 3004, "response_time": 0.680},
            {"ip": "154.16.146.47", "port": "80", "protocol": "http", "upTime": 82.3, "speed": 7058, "response_time": 0.794},
            {"ip": "154.16.146.42", "port": "80", "protocol": "http", "upTime": 84.9, "speed": 8470, "response_time": 1.000},
            {"ip": "154.16.146.41", "port": "80", "protocol": "http", "upTime": 84.7, "speed": 9198, "response_time": 1.000},
            {"ip": "154.16.146.44", "port": "80", "protocol": "http", "upTime": 86.0, "speed": 9565, "response_time": 1.100},
            {"ip": "154.16.146.43", "port": "80", "protocol": "http", "upTime": 84.0, "speed": 9256, "response_time": 1.200},
            {"ip": "154.16.146.48", "port": "80", "protocol": "http", "upTime": 85.1, "speed": 7947, "response_time": 1.210}
        ]
        
    async def test_proxy(self, proxy: str) -> bool:
        """Проверка работоспособности прокси"""
        if proxy in self.failed_proxies:
            return False
            
        if proxy in self.working_proxies:
            last_check = self.working_proxies[proxy]['last_check']
            if (datetime.now() - last_check).total_seconds() < 300:  # 5 минут
                return True
                
        try:
            start_time = time.time()
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'http://ip-api.com/json',
                    proxy=proxy,
                    timeout=3
                ) as response:
                    if response.status == 200:
                        response_time = time.time() - start_time
                        self.working_proxies[proxy] = {
                            'last_check': datetime.now(),
                            'response_time': response_time
                        }
                        return True
                    return False
        except Exception as e:
            self.failed_proxies.add(proxy)
            if proxy in self.working_proxies:
                del self.working_proxies[proxy]
            return False

    async def get_proxy(self) -> Optional[str]:
        """Получает рабочий прокси из кэша или обновляет список"""
        if self.should_update_cache():
            await self.update_cache()
            
        # Сначала проверяем trusted_proxies
        for proxy in self.trusted_proxies:
            proxy_str = f"{proxy['protocol']}://{proxy['ip']}:{proxy['port']}"
            if proxy_str not in self.failed_proxies and await self.test_proxy(proxy_str):
                return proxy_str
        
        # Затем проверяем уже известные рабочие прокси
        working_proxies = list(self.working_proxies.keys())
        for proxy in working_proxies[:5]:  # Проверяем только первые 5
            if await self.test_proxy(proxy):
                return proxy
        
        # Если нет рабочих прокси в кэше, проверяем новые
        for proxy in self.proxies:
            if proxy not in self.failed_proxies and await self.test_proxy(proxy):
                return proxy
        
        # Если все прокси не работают, обновляем кэш
        if self.proxies:
            await self.update_cache()
            # Пробуем еще раз
            for proxy in self.proxies:
                if proxy not in self.failed_proxies and await self.test_proxy(proxy):
                    return proxy
        
        return None

    def should_update_cache(self) -> bool:
        """Проверяет, нужно ли обновить кэш"""
        if not self.last_update:
            return True
        return (datetime.now() - self.last_update).total_seconds() > self.cache_duration

    async def update_cache(self):
        """Обновляет кэш прокси"""
        self.proxies = await get_free_proxies()
        self.last_update = datetime.now()
        # Очищаем устаревшие данные
        self.failed_proxies.clear()
        old_time = datetime.now() - timedelta(minutes=30)
        self.working_proxies = {
            k: v for k, v in self.working_proxies.items() 
            if v['last_check'] > old_time
        }
        logger.info(f"Кэш прокси обновлен. Получено {len(self.proxies)} прокси")

# Создаем глобальный экземпляр менеджера прокси
proxy_manager = ProxyManager()

async def get_working_proxy() -> Optional[str]:
    """Получение рабочего прокси из кэша"""
    return await proxy_manager.get_proxy()

# Экспортируем для использования в других модулях
__all__ = [
    'try_gpt_request',
    'DEFAULT_PROVIDERS',
    'prepare_conversation_kwargs',
    'create_response_stream',
    'get_available_models',
    'user_models',
    'proxy_manager'
] 